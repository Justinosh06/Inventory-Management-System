/*

OOP2124 Object Oriented Programming
LabTest
Name: Your_Name
StudentID: Your_ID

Question 1 (5 marks): what is Object-Oriented Programming (OOP) and what are the benefits using this concepts?

Answer: Object-Oriented Programming (OOP) is a programming method to write code on objects concepts which it is more simplified, comprehensive, and readable for programmers. The benefits of OOP are modularity which encourages programmers to break down complex problems into smaller and more manageable objects, reusability which objects can be reused in different parts of program (saving developing time and effort), encapsulation which data and methods are bundled together within an object (protects data integrity and reduces risk of accidental modification), and inheritance whic new objects can inherit properties and behaviors from existing objects to reuse and reduce redundancy.


*/
