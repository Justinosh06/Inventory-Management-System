/*

OOP2124 Object Oriented Programming
LabTest
Name: Your_Name
StudentID: Your_ID

Question 3 (5 marks): 

Write a Java program (console mode) to check if a number is even or odd.

Answer:

*/
import java.util.*;


class Que3{
    int number;

    public void getNumber(){
        System.out.println("Enter number: ");
        Scanner input = new Scanner(System.in);
        number = input.nextInt();
    }

    public boolean verifyNumber(){
        if(number % 2 == 0){
            return true;
        } else {
            return false;
        }
    }
}