/*

OOP2124 Object Oriented Programming
LabTest
Name: Your_Name
StudentID: Your_ID

Question 4 (5 marks): 

convert the Q3's answer with using Java simple GUI interface to get input and to display the outcome. 

hints: use JOptionPane as input

*/
import java.awt.*;
import javax.swing.*;


class Que4{
    String text;

    public String getInput() {
        text = JOptionPane.showInputDialog("Enter text: ");
        return text;
    }

    public void printOutput() {
        JOptionPane.showMessageDialog(null, getInput());
    }
}