import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import Que5.*;

public class Main{
    public static void main(String[] args) {
        //Q3
        System.out.println("Question 3");
        Que3 q3 = new Que3();
        q3.getNumber();
        if(q3.verifyNumber()){
            System.out.println("Number is even");
        } else if(!q3.verifyNumber()){
            System.out.println("Number is odd");
        }

        //Q4
        System.out.println("\n\nQuestion 4");
        Que4 q4 = new Que4();
        SwingUtilities.invokeLater(q4::printOutput);

        //Q5
        System.out.println("\n\nQuestion 5");
        BankAccount ba = new BankAccount(1234, 24.20, "ABC"); // Create BankAccount FIRST
        Account ac = new Account(ba); // Then pass it to the Account constructor

        ac.printAccountInfo();
        ac.getInfo();
        ac.printAccountInfo();
        ac.Deposit();
        ac.Withdraw();
    }
}