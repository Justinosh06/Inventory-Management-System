/*

OOP2124 Object Oriented Programming
LabTest
Name: Your_Name
StudentID: Your_ID

Question 2 (5 marks): List any TWO(2) main features of OOP?

Answer: One of the main features of OOP is encapsulation which is the process of bundling data and methods that operate on that data within a single unit, or object and helps to protect data from accidental modification and makes code more organized and easier to understand. Besides, inheritance in OOP is another mechanism that allows a new class to inherit properties and methods from an existing class to reuse and reduce redundancy.


*/