package Que5;

import java.util.Scanner;

public class Account{
    Scanner sc = new Scanner(System.in);
    private BankAccount info;

    public Account(BankAccount bankAccount) {
        this.info = bankAccount;
    }


    public void printAccountInfo(){
        System.out.println("Name: " + info.getAccountHolderName() + "\nAccount Number: " + info.getAccountNumber() + "\nBalance: " + info.getBalance());
    }

    public void getInfo(){
        System.out.println("Enter Name: ");
        String name = sc.nextLine();
        info.setAccountHolderName(name);

        System.out.println("Enter Account Number: ");
        int number = sc.nextInt();
        info.setAccountNumber(number);

        System.out.println("Enter Balance: ");
        Double balance = sc.nextDouble();
        info.setBalance(balance);
    }

    public void Deposit(){
        Double balance = info.getBalance();
        Double depositAmount = 2000.0;

        System.out.println("Current Balance: RM" + balance + "\nDeposit: RM" + depositAmount + "\nAfter Deposited: RM" + (balance + depositAmount));
        info.setBalance(balance+depositAmount);
    }

    public void Withdraw(){
        Double balance = info.getBalance();
        Double withdrawAmount = 3000.0;

        System.out.println("Current Balance: RM" + balance + "\nWithdraw: RM" + withdrawAmount + "\nAfter Withdrawn: RM" + (balance - withdrawAmount));
        info.setBalance(balance-withdrawAmount);
    }
}
